// 引入依赖
const express = require('express');
const cors = require('cors');
const app = express();

// 中间件配置（解决跨域 + 解析 JSON 请求体）
app.use(cors()); // 允许跨域请求（前端和后端端口不同时必需）
app.use(express.json()); // 解析前端发送的 JSON 数据
app.use(express.urlencoded({ extended: true })); // 解析表单格式数据

// 模拟数据库：存储合法的用户名和密码（实际项目需替换为真实数据库）
const validUsers = [
  { username: 'admin', password: '123456', token: 'admin_token_123' },
  { username: 'student', password: '654321', token: 'student_token_456' },
  { username: 'azusa', password: 'azusa1226', token: 'azusa_token_789' }
];

// 登录接口（对应前端请求的 /login 路径）
app.post('/login', (req, res) => {
  try {
    // 1. 获取前端传递的用户名和密码
    const { username, password } = req.body;
    console.log('收到登录请求：', username, password);

    // 2. 验证用户名和密码（查询模拟数据库）
    const user = validUsers.find(
      u => u.username === username && u.password === password
    );

    // 3. 返回结果
    if (user) {
      // 登录成功：返回 200 状态码 + token
      res.json({
        code: 200,
        message: '登录成功',
        username: user.username,
        token: user.token // 生成的 token（实际项目需用 jwt 动态生成）
      });
    } else {
      // 登录失败：返回 401 状态码（未授权）
      res.json({
        code: 401,
        message: '用户名或密码错误'
      });
    }
  } catch (error) {
    // 服务器错误：返回 500 状态码
    res.json({
      code: 500,
      message: '服务器内部错误'
    });
  }
});

// 启动后端服务（端口号 3000，需和前端请求地址对应）
const port = 3000;
app.listen(port, () => {
  console.log(`后端服务已启动，监听端口：${port}`);
  console.log(`登录接口地址：http://127.0.0.1:${port}/login`);
});